sudo apt -y update; sudo apt -y install screen git nodejs
npm i fake-useragent
npm i randomstring
npm i request
pip3 install -r requirements.txt
python3 F-Tool.py
